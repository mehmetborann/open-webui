from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Literal
from datetime import datetime, timezone


class HealthResponse(BaseModel):
    """Health check response"""
    status: str = "healthy"
    version: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ChatRequest(BaseModel):
    """Chat request"""
    message: str = Field(..., min_length=1, description="User message (required, cannot be empty)")
    conversation_id: str = Field(..., min_length=21, description="Conversation/Session ID (required, min 21 characters)")
    username: str = Field(..., min_length=1, description="Username for tracking conversations (required, cannot be empty)")
    stream: bool = False
    

class ChatResponse(BaseModel):
    """Chat response"""
    response: str


class ToolInfo(BaseModel):
    """Tool information"""
    name: str
    description: str
    parameters: Dict[str, Any]
    enabled: bool = True


class ToolListResponse(BaseModel):
    """List of available tools"""
    tools: List[ToolInfo]
    count: int
