"""
Database initialization module
Automatically creates tables on startup
"""
import asyncpg
from app.config import settings
import logging
import os

logger = logging.getLogger(__name__)


async def initialize_database():
    """Initialize database tables on startup"""
    try:
        logger.info("Initializing databases...")
        
        # Verify Chat History Database
        await _verify_chat_database()
        
        # Initialize Vector Database
        await _initialize_vector_database()
        
        return True
        
    except Exception as e:
        logger.error(f"Failed to initialize databases: {e}", exc_info=True)
        raise


async def _verify_chat_database():
    """Verify chat history database and tables exist"""
    logger.info("Verifying chat history database...")
    
    # Connect to database
    conn = await asyncpg.connect(
        host=settings.POSTGRES_HOST,
        port=settings.POSTGRES_PORT,
        user=settings.POSTGRES_USER,
        password=settings.POSTGRES_PASSWORD,
        database=settings.POSTGRES_DB
    )
    
    # Verify tables exist
    tables = await conn.fetch("""
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name IN ('chat_sessions', 'chat_messages')
    """)
    
    table_names = [t['table_name'] for t in tables]
    
    if len(table_names) != 2:
        await conn.close()
        missing = set(['chat_sessions', 'chat_messages']) - set(table_names)
        raise RuntimeError(
            f"❌ Required chat tables not found: {missing}. "
            "Run postgres-init scripts to create tables!"
        )
    
    logger.info(f"✓ Chat history database verified. Tables: {', '.join(table_names)}")
    await conn.close()


async def _initialize_vector_database():
    """Verify vector database and PGVector extension"""
    logger.info("Verifying vector database...")
    
    # Connect to vector database
    conn = await asyncpg.connect(
        host=settings.VECTOR_POSTGRES_HOST,
        port=settings.VECTOR_POSTGRES_PORT,
        user=settings.VECTOR_POSTGRES_USER,
        password=settings.VECTOR_POSTGRES_PASSWORD,
        database=settings.VECTOR_POSTGRES_DB
    )
    
    # Check if PGVector extension is enabled
    try:
        result = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM pg_extension WHERE extname = 'vector')"
        )
        if not result:
            await conn.close()
            raise RuntimeError(
                "❌ PGVector extension not found! "
                "Run postgres-init scripts to enable the extension."
            )
        logger.info("✓ PGVector extension verified")
    except asyncpg.PostgresError as e:
        await conn.close()
        raise RuntimeError(f"❌ PGVector extension check failed: {e}")
    
    # Note: LangChain will auto-create langchain_pg_collection and langchain_pg_embedding tables
    logger.info("✓ Vector database verified (PGVector tables will be auto-created on first use)")
    
    await conn.close()


async def check_database_health():
    """Check if database is accessible"""
    try:
        conn = await asyncpg.connect(
            host=settings.POSTGRES_HOST,
            port=settings.POSTGRES_PORT,
            user=settings.POSTGRES_USER,
            password=settings.POSTGRES_PASSWORD,
            database=settings.POSTGRES_DB
        )
        
        # Simple query to check connection
        result = await conn.fetchval("SELECT 1")
        await conn.close()
        
        return result == 1
    except Exception as e:
        logger.error(f"Database health check failed: {e}")
        return False
