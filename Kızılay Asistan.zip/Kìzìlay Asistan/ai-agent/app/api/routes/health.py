from fastapi import APIRouter
from app.models.schemas import HealthResponse
from app.config import settings
from app.db.init_db import check_database_health
from datetime import datetime, timezone

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint with database verification"""
    db_healthy = await check_database_health()
    
    return HealthResponse(
        status="healthy" if db_healthy else "degraded",
        version=settings.APP_VERSION,
        timestamp=datetime.now(timezone.utc)
    )


@router.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running"
    }
