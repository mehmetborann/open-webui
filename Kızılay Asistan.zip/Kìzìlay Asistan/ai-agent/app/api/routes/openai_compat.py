from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional, Literal, AsyncGenerator
from app.api.dependencies import verify_api_key
from app.core.agent import get_agent
import json
import logging
import time
import uuid

router = APIRouter()
logger = logging.getLogger(__name__)


class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str


class OpenAIChatRequest(BaseModel):
    model: str = "kizilay-agent"
    messages: List[ChatMessage]
    stream: bool = False
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = None
    user: Optional[str] = None


class OpenAIChatChoice(BaseModel):
    index: int = 0
    message: ChatMessage
    finish_reason: str = "stop"


class OpenAIChatResponse(BaseModel):
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[OpenAIChatChoice]
    usage: Dict[str, int] = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}


async def generate_openai_stream(
    messages: List[ChatMessage],
    conversation_id: str,
    username: str,
    model: str
) -> AsyncGenerator[str, None]:
    """Generate OpenAI-compatible streaming response"""
    try:
        agent = get_agent()
        
        # Get last user message
        user_message = next((msg.content for msg in reversed(messages) if msg.role == "user"), "")
        
        chunk_id = f"chatcmpl-{uuid.uuid4().hex[:8]}"
        created = int(time.time())
        
        # Send initial chunk
        initial_chunk = {
            "id": chunk_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{
                "index": 0,
                "delta": {"role": "assistant", "content": ""},
                "finish_reason": None
            }]
        }
        yield f"data: {json.dumps(initial_chunk)}\n\n"
        
        # Stream tokens from agent
        async for chunk in agent.astream(user_message, conversation_id, username=username):
            if chunk.get("type") == "token":
                token_chunk = {
                    "id": chunk_id,
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": model,
                    "choices": [{
                        "index": 0,
                        "delta": {"content": chunk.get("content", "")},
                        "finish_reason": None
                    }]
                }
                yield f"data: {json.dumps(token_chunk)}\n\n"
        
        # Send final chunk
        final_chunk = {
            "id": chunk_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{
                "index": 0,
                "delta": {},
                "finish_reason": "stop"
            }]
        }
        yield f"data: {json.dumps(final_chunk)}\n\n"
        yield "data: [DONE]\n\n"
        
    except Exception as e:
        logger.error(f"OpenAI streaming error: {e}")
        error_chunk = {
            "error": {
                "message": str(e),
                "type": "internal_error"
            }
        }
        yield f"data: {json.dumps(error_chunk)}\n\n"


@router.post("/v1/chat/completions")
async def openai_chat_completions(
    request: OpenAIChatRequest,
    api_key: str = Depends(verify_api_key)
):
    """
    OpenAI-compatible chat completions endpoint
    Compatible with LibreChat and other OpenAI clients
    """
    try:
        # Extract username and conversation_id from messages or generate
        username = request.user or "librechat-user"
        conversation_id = f"librechat-{uuid.uuid4().hex[:21]}"
        
        # Get last user message
        user_message = next((msg.content for msg in reversed(request.messages) if msg.role == "user"), "")
        
        if not user_message:
            raise HTTPException(status_code=400, detail="No user message found")
        
        logger.info(f"📥 OpenAI API request - model: {request.model} | user: {username} | stream: {request.stream}")
        
        if request.stream:
            return StreamingResponse(
                generate_openai_stream(request.messages, conversation_id, username, request.model),
                media_type="text/event-stream"
            )
        
        # Non-streaming mode
        agent = get_agent()
        result = await agent.ainvoke(user_message, conversation_id, username=username)
        
        response = OpenAIChatResponse(
            id=f"chatcmpl-{uuid.uuid4().hex[:8]}",
            created=int(time.time()),
            model=request.model,
            choices=[
                OpenAIChatChoice(
                    message=ChatMessage(
                        role="assistant",
                        content=result["response"]
                    )
                )
            ]
        )
        
        return response
        
    except Exception as e:
        logger.error(f"OpenAI API error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/v1/models")
async def list_models(api_key: str = Depends(verify_api_key)):
    """List available models (OpenAI-compatible)"""
    return {
        "object": "list",
        "data": [
            {
                "id": "kizilay-agent",
                "object": "model",
                "created": int(time.time()),
                "owned_by": "kizilay",
                "permission": [],
                "root": "kizilay-agent",
                "parent": None
            }
        ]
    }
