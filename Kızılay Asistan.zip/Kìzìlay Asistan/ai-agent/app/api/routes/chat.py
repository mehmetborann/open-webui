from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from app.models.schemas import ChatRequest, ChatResponse
from app.api.dependencies import verify_api_key
from app.core.agent import get_agent
import json
import logging
from typing import AsyncGenerator, Optional

router = APIRouter()
logger = logging.getLogger(__name__)


async def generate_chat_stream(message: str, conversation_id: str, username: str) -> AsyncGenerator[str, None]:
    """Generate streaming chat response with token-level chunks"""
    try:
        agent = get_agent()
        
        async for chunk in agent.astream(message, conversation_id, username=username):
            # Stream token chunks as Server-Sent Events
            if chunk.get("type") == "token":
                yield f"data: {json.dumps(chunk)}\n\n"
        
        yield "data: [DONE]\n\n"
        
    except Exception as e:
        logger.error(f"Streaming error: {e}")
        error_chunk = {"type": "error", "error": str(e)}
        yield f"data: {json.dumps(error_chunk)}\n\n"


@router.post("/chat", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    api_key: str = Depends(verify_api_key)
):
    """
    Chat endpoint
    
    Send a message to the AI agent and get a response.
    Supports streaming mode.
    """
    try:
        # Log incoming request for debugging
        logger.info(f"📥 Chat request - message: '{request.message[:50]}...' | conv_id: {request.conversation_id} | user: {request.username} | stream: {request.stream}")
        
        # conversation_id is now required from client
        conversation_id = request.conversation_id
        
        if request.stream:
            return StreamingResponse(
                generate_chat_stream(request.message, conversation_id, request.username),
                media_type="text/event-stream"
            )
        
        # Non-streaming mode
        agent = get_agent()
        result = await agent.ainvoke(
            request.message, 
            conversation_id,
            username=request.username
        )
        
        return ChatResponse(
            response=result["response"]
        )
        
    except Exception as e:
        logger.error(f"Chat error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
