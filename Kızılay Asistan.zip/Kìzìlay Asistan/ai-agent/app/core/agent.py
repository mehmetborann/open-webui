from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import ToolNode
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from app.core.state import AgentState
from app.core.registry import tool_registry
from app.core.chat_history import get_chat_history_manager
from app.config import settings
from typing import Literal, AsyncGenerator
import logging

logger = logging.getLogger(__name__)


class Agent:
    """LangGraph Agent with tool support"""
    
    def __init__(self):
        self.llm = None
        self.graph = None
        self._initialize()
    
    def _initialize(self):
        """Initialize the agent"""
        try:
            # Initialize LLM
            self.llm = ChatOpenAI(
                model=settings.OPENAI_MODEL,
                temperature=0.7,
                streaming=True
            )
            
            # Get tools (now they are already LangChain BaseTool instances)
            langchain_tools = tool_registry.get_tools()
            logger.info(f"Agent initialized with {len(langchain_tools)} tools")
            
            # Bind tools to LLM
            self.llm_with_tools = self.llm.bind_tools(langchain_tools)
            
            # Build graph
            self.graph = self._build_graph(langchain_tools)
            
            logger.info("Agent graph compiled successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize agent: {e}")
            raise
    
    def _build_graph(self, tools: list) -> StateGraph:
        """Build LangGraph workflow"""
        
        # Create the graph
        workflow = StateGraph(AgentState)
        
        # Add nodes
        workflow.add_node("agent", self._call_model)
        workflow.add_node("tools", ToolNode(tools))
        
        # Add edges
        workflow.add_edge(START, "agent")
        workflow.add_conditional_edges(
            "agent",
            self._should_continue,
            {
                "tools": "tools",
                "end": END
            }
        )
        workflow.add_edge("tools", "agent")
        
        # Compile
        return workflow.compile()
    
    def _get_system_message(self) -> SystemMessage:
        """Get system message for agent"""
        return SystemMessage(
            content="You are a helpful AI assistant with access to various tools. "
                    "Use the search_knowledge_base tool to find information in the knowledge base. "
                    "Use the http_request tool to make HTTP requests to external APIs. "
                    "Always provide clear and helpful responses."
        )
    
    def _call_model(self, state: AgentState) -> dict:
        """Call the LLM with current state"""
        messages = state["messages"]
        response = self.llm_with_tools.invoke(messages)
        return {"messages": [response]}
    
    def _should_continue(self, state: AgentState) -> Literal["tools", "end"]:
        """Determine if we should continue to tools or end"""
        messages = state["messages"]
        last_message = messages[-1]
        
        # If there are tool calls, continue to tools
        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            tool_names = [tc["name"] for tc in last_message.tool_calls]
            logger.info(f"Agent decided to use tools: {', '.join(tool_names)}")
            return "tools"
        
        # Otherwise, end
        logger.info("Agent decided to respond directly (no tools needed)")
        return "end"
    
    async def ainvoke(self, message: str, conversation_id: str, **kwargs) -> dict:
        """
        Invoke the agent asynchronously
        
        Args:
            message: User message
            conversation_id: Conversation ID for tracking
            **kwargs: Additional metadata (username, history_limit, etc.)
            
        Returns:
            Agent response with messages and metadata
        """
        try:
            # Load chat history
            username = kwargs.get("username")
            history_manager = await get_chat_history_manager()
            await history_manager.create_session(conversation_id, username=username)
            
            # Get previous messages from history
            previous_messages = await history_manager.get_langchain_messages(
                conversation_id,
                limit=kwargs.get("history_limit", settings.AGENT_HISTORY_LIMIT)
            )
            
            # Create initial state with history and system message
            all_messages = [self._get_system_message()] + previous_messages + [HumanMessage(content=message)]
            initial_state = AgentState(
                messages=all_messages,
                conversation_id=conversation_id,
                metadata=kwargs.get("metadata", {})
            )
            
            # Invoke graph
            result = await self.graph.ainvoke(
                initial_state,
                {"recursion_limit": settings.AGENT_MAX_ITERATIONS}
            )
            
            # Extract final message
            final_message = result["messages"][-1]
            
            # Save messages to history (don't fail if history save fails)
            try:
                await history_manager.add_message(
                    conversation_id,
                    "human",
                    message,
                    metadata=kwargs.get("metadata", {})
                )
                logger.debug(f"Saved user message to history: {conversation_id}")
                
                # Save AI response
                await history_manager.add_message(
                    conversation_id,
                    "ai",
                    final_message.content,
                    metadata={
                        "model": settings.OPENAI_MODEL,
                        "tool_calls": getattr(final_message, "tool_calls", None)
                    }
                )
                logger.debug(f"Saved AI response to history: {conversation_id}")
            except Exception as history_error:
                logger.error(f"Failed to save to history: {history_error}", exc_info=True)
                # Continue anyway - don't fail the whole request
            
            return {
                "response": final_message.content,
                "conversation_id": conversation_id,
                "metadata": {
                    "model": settings.OPENAI_MODEL,
                    "message_count": len(result["messages"])
                }
            }
            
        except Exception as e:
            logger.error(f"Agent invocation failed: {e}", exc_info=True)
            raise
    
    async def astream(self, message: str, conversation_id: str, **kwargs) -> AsyncGenerator[dict, None]:
        """
        Stream agent responses with token-level streaming
        
        Args:
            message: User message
            conversation_id: Conversation ID
            **kwargs: Additional parameters (username, history_limit, etc.)
            
        Yields:
            Streamed token chunks from the agent
        """
        try:
            logger.info(f"Starting streaming for conversation: {conversation_id}")
            
            # Load chat history
            username = kwargs.get("username")
            history_manager = await get_chat_history_manager()
            await history_manager.create_session(conversation_id, username=username)
            
            # Get previous messages from history
            previous_messages = await history_manager.get_langchain_messages(
                conversation_id,
                limit=kwargs.get("history_limit", settings.AGENT_HISTORY_LIMIT)
            )
            
            # Create initial state with system message and history
            all_messages = [self._get_system_message()] + previous_messages + [HumanMessage(content=message)]
            initial_state = AgentState(
                messages=all_messages,
                conversation_id=conversation_id,
                metadata=kwargs.get("metadata", {})
            )
            
            final_response = ""
            tool_calls_used = []  # Track for history only
            
            # Use astream_events for token-level streaming
            async for event in self.graph.astream_events(
                initial_state,
                {"recursion_limit": settings.AGENT_MAX_ITERATIONS},
                version="v2"
            ):
                event_type = event["event"]
                
                # Stream LLM token chunks
                if event_type == "on_chat_model_stream":
                    chunk = event["data"]["chunk"]
                    if hasattr(chunk, "content") and chunk.content:
                        final_response += chunk.content
                        yield {"type": "token", "content": chunk.content}
                
                # Track tool calls for history (but don't yield them)
                elif event_type == "on_tool_start":
                    tool_name = event["name"]
                    tool_input = event["data"].get("input", {})
                    logger.info(f"Tool started: {tool_name}")
                    tool_calls_used.append({"name": tool_name, "input": tool_input})
                
                elif event_type == "on_tool_end":
                    tool_name = event["name"]
                    logger.info(f"Tool completed: {tool_name}")
            
            # Save to history after streaming completes (don't fail if history save fails)
            if final_response:
                try:
                    await history_manager.add_message(
                        conversation_id,
                        "human",
                        message,
                        metadata=kwargs.get("metadata", {})
                    )
                    logger.debug(f"Saved user message to history: {conversation_id}")
                    
                    await history_manager.add_message(
                        conversation_id,
                        "ai",
                        final_response,
                        metadata={
                            "model": settings.OPENAI_MODEL,
                            "tool_calls": tool_calls_used if tool_calls_used else None
                        }
                    )
                    logger.debug(f"Saved AI response to history: {conversation_id}")
                    logger.info(f"Streaming completed for conversation: {conversation_id}")
                except Exception as history_error:
                    logger.error(f"Failed to save streaming history: {history_error}", exc_info=True)
                    # Continue anyway - user already got their response
                
        except Exception as e:
            logger.error(f"Agent streaming failed: {e}", exc_info=True)
            raise


# Global agent instance
_agent_instance = None


def get_agent() -> Agent:
    """Get or create global agent instance"""
    global _agent_instance
    if _agent_instance is None:
        _agent_instance = Agent()
    return _agent_instance
