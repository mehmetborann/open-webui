from typing import List, Optional, Dict, Any
from datetime import datetime
import json
import asyncpg
from app.config import settings
import logging

logger = logging.getLogger(__name__)


class ChatHistoryManager:
    """Manage chat history in PostgreSQL"""
    
    def __init__(self):
        self.pool: Optional[asyncpg.Pool] = None
    
    async def initialize(self):
        """Initialize database connection pool"""
        try:
            self.pool = await asyncpg.create_pool(
                host=settings.POSTGRES_HOST,
                port=settings.POSTGRES_PORT,
                user=settings.POSTGRES_USER,
                password=settings.POSTGRES_PASSWORD,
                database=settings.POSTGRES_DB,
                min_size=2,
                max_size=10
            )
            logger.info("Chat history manager initialized")
        except Exception as e:
            logger.error(f"Failed to initialize chat history manager: {e}")
            raise
    
    async def close(self):
        """Close database connection pool"""
        if self.pool:
            await self.pool.close()
    
    def _ensure_initialized(self):
        """Ensure database pool is initialized"""
        if self.pool is None:
            raise RuntimeError(
                "ChatHistoryManager not initialized. "
                "Call initialize() or use get_chat_history_manager()"
            )
    
    async def create_session(self, conversation_id: str, username: Optional[str] = None, metadata: Dict[str, Any] = None) -> str:
        """Create a new chat session (or get existing one). Returns conversation_id."""
        self._ensure_initialized()
        
        if metadata is None:
            metadata = {}
        
        try:
            async with self.pool.acquire() as conn:
                # Check if session exists
                existing = await conn.fetchrow(
                    "SELECT conversation_id FROM chat_sessions WHERE conversation_id = $1",
                    conversation_id
                )
                
                if existing:
                    return conversation_id
                
                # Create new session
                await conn.execute(
                    """
                    INSERT INTO chat_sessions (conversation_id, username, metadata)
                    VALUES ($1, $2, $3::jsonb)
                    """,
                    conversation_id,
                    username,
                    json.dumps(metadata)
                )
                return conversation_id
        except asyncpg.PostgresError as e:
            logger.error(f"Database error creating session {conversation_id}: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error creating session {conversation_id}: {e}")
            raise
    
    async def add_message(
        self,
        conversation_id: str,
        message_type: str,
        content: str,
        metadata: Dict[str, Any] = None
    ) -> str:
        """Add a message to chat history"""
        self._ensure_initialized()
        
        if metadata is None:
            metadata = {}
        
        try:
            async with self.pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    INSERT INTO chat_messages (conversation_id, message_type, content, metadata)
                    VALUES ($1, $2, $3, $4::jsonb)
                    RETURNING id
                    """,
                    conversation_id,
                    message_type,
                    content,
                    json.dumps(metadata)
                )
                
                if row is None:
                    logger.error(f"Failed to insert message for {conversation_id}")
                    raise RuntimeError("Database insert returned no row")
                
                return str(row['id'])
        except asyncpg.PostgresError as e:
            logger.error(f"Database error adding message to {conversation_id}: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error adding message to {conversation_id}: {e}")
            raise
    
    async def get_messages(
        self,
        conversation_id: str,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get chat messages for a conversation"""
        self._ensure_initialized()
        
        try:
            async with self.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT 
                        id,
                        message_type,
                        content,
                        metadata,
                        created_at
                    FROM chat_messages
                    WHERE conversation_id = $1
                    ORDER BY created_at ASC
                    LIMIT $2
                    """,
                    conversation_id,
                    limit
                )
                
                return [
                    {
                        'id': str(row['id']),
                        'type': row['message_type'],
                        'content': row['content'],
                        'metadata': row['metadata'],
                        'created_at': row['created_at'].isoformat()
                    }
                    for row in rows
                ]
        except asyncpg.PostgresError as e:
            logger.error(f"Database error fetching messages for {conversation_id}: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error fetching messages for {conversation_id}: {e}")
            raise    
    async def get_langchain_messages(
        self,
        conversation_id: str,
        limit: int = 10
    ) -> List:
        """
        Get messages in LangChain format
        
        This follows LangChain's BaseChatMessageHistory interface pattern
        """
        self._ensure_initialized()
        
        from langchain_core.messages import (
            HumanMessage, 
            AIMessage, 
            SystemMessage, 
            ToolMessage,
            BaseMessage
        )
        
        try:
            messages_data = await self.get_messages(conversation_id, limit)
        except Exception as e:
            logger.error(f"Error fetching LangChain messages for {conversation_id}: {e}")
            return []  # Return empty list instead of crashing
        langchain_messages: List[BaseMessage] = []
        
        for msg in messages_data:
            msg_type = msg['type']
            content = msg['content']
            
            if msg_type == 'human':
                langchain_messages.append(HumanMessage(content=content))
            elif msg_type == 'ai':
                langchain_messages.append(AIMessage(content=content))
            elif msg_type == 'system':
                langchain_messages.append(SystemMessage(content=content))
            elif msg_type == 'tool':
                langchain_messages.append(ToolMessage(
                    content=content,
                    tool_call_id=msg['metadata'].get('tool_call_id', '')
                ))
        
        return langchain_messages
    
    async def get_session_count(self) -> int:
        """Get total number of sessions"""
        self._ensure_initialized()
        
        try:
            async with self.pool.acquire() as conn:
                row = await conn.fetchrow("SELECT COUNT(*) as count FROM chat_sessions")
                return row['count'] if row else 0
        except asyncpg.PostgresError as e:
            logger.error(f"Database error getting session count: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error getting session count: {e}")
            raise


# Singleton instance
_chat_history_manager: Optional[ChatHistoryManager] = None


async def get_chat_history_manager() -> ChatHistoryManager:
    """Get or create chat history manager singleton"""
    global _chat_history_manager
    
    if _chat_history_manager is None:
        _chat_history_manager = ChatHistoryManager()
        await _chat_history_manager.initialize()
    
    return _chat_history_manager
