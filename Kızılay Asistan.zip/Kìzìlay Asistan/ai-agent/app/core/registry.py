from typing import Dict, List, Optional, Type
from langchain_core.tools import BaseTool
import logging

logger = logging.getLogger(__name__)


class ToolRegistry:
    """Registry for managing LangChain BaseTool instances"""
    
    def __init__(self):
        self._tools: Dict[str, BaseTool] = {}
        self._tool_classes: Dict[str, Type[BaseTool]] = {}
    
    def register_tool(self, tool: BaseTool) -> None:
        """Register a tool instance"""
        if tool.name in self._tools:
            logger.warning(f"Tool {tool.name} already registered, overwriting")
        
        self._tools[tool.name] = tool
        logger.info(f"Registered tool: {tool.name}")
    
    def register_tool_class(self, name: str, tool_class: Type[BaseTool]) -> None:
        """Register a tool class for lazy loading"""
        self._tool_classes[name] = tool_class
        logger.info(f"Registered tool class: {name}")
    
    def get_tool(self, name: str) -> Optional[BaseTool]:
        """Get a tool by name"""
        # First check if instance exists
        if name in self._tools:
            return self._tools[name]
        
        # Try to instantiate from class
        if name in self._tool_classes:
            tool_class = self._tool_classes[name]
            tool = tool_class()
            self._tools[name] = tool
            return tool
        
        return None
    
    def get_tools(self) -> List[BaseTool]:
        """Get all registered tools"""
        return list(self._tools.values())
    
    def remove_tool(self, name: str) -> bool:
        """Remove a tool from registry"""
        if name in self._tools:
            del self._tools[name]
            logger.info(f"Removed tool: {name}")
            return True
        return False
    
    def list_tool_names(self) -> List[str]:
        """List all registered tool names"""
        return list(self._tools.keys())
    
    def clear(self) -> None:
        """Clear all registered tools"""
        self._tools.clear()
        self._tool_classes.clear()
        logger.info("Cleared all tools from registry")


# Global registry instance
tool_registry = ToolRegistry()
