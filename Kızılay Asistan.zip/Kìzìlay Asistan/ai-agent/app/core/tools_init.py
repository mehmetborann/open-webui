from app.core.registry import tool_registry
from app.core.tools import PGVectorSearchTool, HTTPRequestTool
from app.core.tools.datetime_tool import DateTimeTool
import logging

logger = logging.getLogger(__name__)


def initialize_tools():
    """Initialize and register all tools"""
    
    # Register PGVector Search Tool
    pgvector_tool = PGVectorSearchTool()
    tool_registry.register_tool(pgvector_tool)
    
    # Register HTTP Request Tool
    http_tool = HTTPRequestTool()
    tool_registry.register_tool(http_tool)
    
    # Register DateTime Tool
    datetime_tool = DateTimeTool()
    tool_registry.register_tool(datetime_tool)
    
    logger.info(f"Initialized {len(tool_registry.get_tools())} tools")
    
    return tool_registry
