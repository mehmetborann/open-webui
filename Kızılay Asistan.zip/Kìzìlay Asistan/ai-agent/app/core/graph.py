"""
LangGraph Studio için graph export modülü
"""
from app.core.agent import get_agent

# LangGraph Studio için graph'ı export et
agent_instance = get_agent()
graph = agent_instance.graph
