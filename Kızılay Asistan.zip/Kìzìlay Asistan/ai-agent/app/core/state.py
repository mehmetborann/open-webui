from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from langchain_core.messages import BaseMessage


class AgentState(TypedDict):
    """
    State for the agent graph
    
    Attributes:
        messages: List of chat messages with automatic merging
        conversation_id: Conversation identifier
        metadata: Additional metadata
    """
    messages: Annotated[list[BaseMessage], add_messages]
    conversation_id: str
    metadata: dict
