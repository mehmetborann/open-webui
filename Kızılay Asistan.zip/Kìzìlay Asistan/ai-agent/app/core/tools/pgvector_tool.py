from langchain_core.tools import BaseTool
from app.config import settings
from langchain_openai import OpenAIEmbeddings
from langchain_postgres import PGVector
from typing import Any, Dict, Optional
import logging

logger = logging.getLogger(__name__)


class PGVectorSearchTool(BaseTool):
    """Tool for searching in PGVector database"""
    
    name: str = "search_knowledge_base"
    description: str = """Search the knowledge base using semantic similarity. 
    Input: A search query string describing what information you need.
    Use this tool when you need to find relevant information from stored documents, documentation, or knowledge base.
    Returns the most relevant document excerpts with their sources."""
    vectorstore: Optional[PGVector] = None
    
    def __init__(self):
        super().__init__()
        self._initialize_vectorstore()
    
    def _initialize_vectorstore(self):
        """Initialize PGVector connection"""
        try:
            embeddings = OpenAIEmbeddings(model=settings.OPENAI_EMBEDDING_MODEL)
            self.vectorstore = PGVector(
                embeddings=embeddings,
                collection_name=settings.VECTOR_COLLECTION_NAME,
                connection=settings.VECTOR_DATABASE_URL,
                use_jsonb=True,
            )
            logger.info(f"PGVector initialized with collection: {settings.VECTOR_COLLECTION_NAME}")
        except Exception as e:
            logger.error(f"Failed to initialize PGVector: {e}")
            raise
    
    def _run(self, query: str, k: Optional[int] = None) -> str:
        """Sync search - not recommended, use _arun"""
        import asyncio
        return asyncio.run(self._arun(query, k))
    
    async def _arun(self, query: str, k: Optional[int] = None) -> str:
        """Search in vector database"""
        if not self.vectorstore:
            return "Error: Vector database not initialized"
        
        # Use settings value if k not provided
        if k is None:
            k = settings.VECTOR_SEARCH_K
        
        try:
            # Perform similarity search
            results = self.vectorstore.similarity_search(query, k=k)
            
            # Format results as string
            if not results:
                return f"No results found for query: {query}"
            
            formatted_results = []
            for i, doc in enumerate(results, 1):
                formatted_results.append(
                    f"Result {i}:\n{doc.page_content}\n"
                    f"Source: {doc.metadata.get('source', 'Unknown')}"
                )
            
            return f"Found {len(results)} results for '{query}':\n\n" + "\n\n".join(formatted_results)
            
        except Exception as e:
            logger.error(f"Error searching vector database: {e}")
            return f"Error searching vector database: {str(e)}"
