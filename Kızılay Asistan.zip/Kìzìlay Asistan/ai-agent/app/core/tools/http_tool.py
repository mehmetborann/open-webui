from langchain_core.tools import BaseTool
from typing import Any, Dict, Optional
import httpx
import logging
import json

logger = logging.getLogger(__name__)


class HTTPRequestTool(BaseTool):
    """Tool for making HTTP requests"""
    
    name: str = "http_request"
    description: str = "Make HTTP GET requests to external APIs and URLs. Use this to fetch data from web endpoints."
    timeout: int = 30
    
    def _run(self, url: str, method: str = "GET") -> str:
        """Sync HTTP request - not recommended, use _arun"""
        import asyncio
        return asyncio.run(self._arun(url, method))
    
    async def _arun(self, url: str, method: str = "GET") -> str:
        """Make HTTP request"""
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                
                if method.upper() == "GET":
                    response = await client.get(url)
                elif method.upper() == "POST":
                    response = await client.post(url)
                else:
                    return f"Error: Unsupported method {method}. Only GET and POST supported."
                
                # Try to parse JSON, fallback to text
                try:
                    response_data = response.json()
                    data_str = json.dumps(response_data, indent=2)
                except:
                    data_str = response.text
                
                return f"HTTP {method.upper()} {url}\nStatus: {response.status_code}\n\nResponse:\n{data_str}"
                
        except httpx.TimeoutException:
            logger.error(f"Request timeout for {url}")
            return f"Error: Request timeout for {url}"
        except Exception as e:
            logger.error(f"HTTP request error: {e}")
            return f"Error: {str(e)}"
