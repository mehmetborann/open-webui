from langchain.tools import BaseTool
from datetime import datetime, timezone, timedelta


class DateTimeTool(BaseTool):
    name: str = "get_current_datetime"
    description: str = "Get current date and time"
    
    def _run(self, query: str = "") -> str:
        """Get current datetime in ISO 8601 format"""
        turkey_offset = timezone(timedelta(hours=3))
        return datetime.now(turkey_offset).isoformat()
    
    async def _arun(self, query: str = "") -> str:
        return self._run(query)
