from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator, ValidationInfo
import os


class Settings(BaseSettings):
    """Application settings - All values must be provided in .env"""
    
    # App Config
    APP_NAME: str
    APP_VERSION: str
    DEBUG: bool
    HOST: str
    PORT: int
    
    # OpenAI
    OPENAI_API_KEY: str
    OPENAI_MODEL: str
    OPENAI_EMBEDDING_MODEL: str
    
    # PostgreSQL (Chat History)
    POSTGRES_USER: str
    POSTGRES_PASSWORD: str
    POSTGRES_DB: str
    POSTGRES_HOST: str
    POSTGRES_PORT: int
    
    # PostgreSQL (Vector Store)
    VECTOR_POSTGRES_USER: str
    VECTOR_POSTGRES_PASSWORD: str
    VECTOR_POSTGRES_DB: str
    VECTOR_POSTGRES_HOST: str
    VECTOR_POSTGRES_PORT: int
    
    @property
    def DATABASE_URL(self) -> str:
        """PostgreSQL connection string for chat history"""
        return f"postgresql+psycopg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
    
    @property
    def ASYNC_DATABASE_URL(self) -> str:
        """Async PostgreSQL connection string for chat history"""
        return f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
    
    @property
    def VECTOR_DATABASE_URL(self) -> str:
        """PostgreSQL connection string for vector store"""
        return f"postgresql+psycopg://{self.VECTOR_POSTGRES_USER}:{self.VECTOR_POSTGRES_PASSWORD}@{self.VECTOR_POSTGRES_HOST}:{self.VECTOR_POSTGRES_PORT}/{self.VECTOR_POSTGRES_DB}"
    
    # Vector Store
    VECTOR_COLLECTION_NAME: str
    VECTOR_SEARCH_K: int
    
    # Agent Config
    AGENT_MAX_ITERATIONS: int
    AGENT_TIMEOUT: int
    AGENT_HISTORY_LIMIT: int
    
    # API Keys
    API_KEY: str
    
    # CORS
    CORS_ORIGINS: list[str] = []
    
    @field_validator('CORS_ORIGINS', mode='before')
    @classmethod
    def parse_cors_origins(cls, v):
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(',')]
        return v
    
    # Logging
    LOG_LEVEL: str
    
    model_config = SettingsConfigDict(
        case_sensitive=True,
        env_file_encoding='utf-8'
    )


# Global settings instance
settings = Settings()
