from fastapi import APIRouter
from datetime import datetime
from app.schemas.upload import HealthResponse
from app.core.config import settings

router = APIRouter()


@router.get("/", tags=["health"])
async def root():
    """Root endpoint"""
    return {
        "message": settings.APP_NAME,
        "version": settings.APP_VERSION
    }


@router.get("/health", response_model=HealthResponse, tags=["health"])
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.utcnow().isoformat()
    )
