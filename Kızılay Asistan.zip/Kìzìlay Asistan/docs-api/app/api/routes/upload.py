from fastapi import APIRouter, File, UploadFile, Depends, HTTPException, Form
from sqlalchemy.orm import Session
from typing import Optional
import uuid
import logging
from app.core.database import get_db
from app.core.config import settings
from app.models.database import UploadLog
from app.services.minio import MinIOService, calculate_file_hash
from app.services.docling import DoclingService
from app.services.vector import VectorService
from app.schemas.upload import UploadResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/upload", tags=["upload"])

# Initialize services
minio_service = MinIOService()
docling_service = DoclingService()
vector_service = VectorService()


@router.post("", response_model=UploadResponse)
async def upload_document(
    file: UploadFile = File(...),
    username: str = Form(...),
    tenant: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    """
    Upload and process a document
    
    Workflow:
    1. Calculate file hash and check if already uploaded
    2. Create upload log with pending status
    3. Upload to MinIO
    4. Update status to processing
    5. Send to Docling for conversion
    6. Store chunks in vector database
    7. Update status to completed
    """
    try:
        # Read file content
        file_content = await file.read()
        file_size = len(file_content)
        
        # Check file size
        if file_size > settings.UPLOAD_MAX_SIZE:
            raise HTTPException(
                status_code=400,
                detail=f"File size exceeds maximum allowed size of {settings.UPLOAD_MAX_SIZE} bytes"
            )
        
        # Calculate hash
        file_hash = calculate_file_hash(file_content)
        logger.info(f"File hash calculated: {file_hash}")
        
        # Check if file already exists
        existing_upload = db.query(UploadLog).filter(
            UploadLog.hash == file_hash,
            UploadLog.status != 'failed'
        ).first()
        
        if existing_upload:
            logger.info(f"File already exists with upload_id: {existing_upload.upload_id}")
            return UploadResponse(
                message="File already uploaded",
                upload_id=str(existing_upload.upload_id),
                status=existing_upload.status,
                filename=existing_upload.filename,
                hash=file_hash,
                existing=True
            )
        
        # Create upload log
        upload_id = uuid.uuid4()
        object_key = f"{tenant or 'default'}/{upload_id}/{file.filename}"
        
        upload_log = UploadLog(
            upload_id=upload_id,
            username=username,
            filename=file.filename,
            mime=file.content_type,
            hash=file_hash,
            object_key=object_key,
            size=file_size,
            tenant=tenant,
            status='pending'
        )
        
        db.add(upload_log)
        db.commit()
        logger.info(f"Upload log created with upload_id: {upload_id}")
        
        # Upload to MinIO
        upload_success = minio_service.upload_file(
            file_content,
            object_key,
            file.content_type or 'application/octet-stream'
        )
        
        if not upload_success:
            upload_log.status = 'failed'
            upload_log.error = 'Failed to upload to MinIO'
            db.commit()
            raise HTTPException(status_code=500, detail="Failed to upload file to storage")
        
        # Update status to processing
        upload_log.status = 'processing'
        db.commit()
        logger.info(f"File uploaded to MinIO, status updated to processing")
        
        # Convert with Docling
        markdown_content = await docling_service.convert_to_markdown(
            file_content,
            file.filename,
            file.content_type or 'application/octet-stream'
        )
        
        if not markdown_content:
            upload_log.status = 'failed'
            upload_log.error = 'Failed to convert document with Docling'
            db.commit()
            raise HTTPException(status_code=500, detail="Failed to convert document")
        
        logger.info(f"Document converted to markdown successfully")
        
        # Process and store in vector database
        metadata = {
            'filename': file.filename,
            'mime_type': file.content_type,
            'username': username,
            'tenant': tenant,
            'upload_id': str(upload_id)
        }
        
        vector_success = await vector_service.process_and_store_document(
            markdown_content,
            upload_id,
            metadata
        )
        
        if not vector_success:
            upload_log.status = 'failed'
            upload_log.error = 'Failed to store in vector database'
            db.commit()
            raise HTTPException(status_code=500, detail="Failed to process document chunks")
        
        # Update status to completed
        upload_log.status = 'completed'
        db.commit()
        logger.info(f"Document processing completed for upload_id: {upload_id}")
        
        return UploadResponse(
            message="Document uploaded and processed successfully",
            upload_id=str(upload_id),
            status="completed",
            filename=file.filename,
            hash=file_hash,
            existing=False
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing upload: {e}", exc_info=True)
        
        # Update upload log if it exists
        if 'upload_log' in locals():
            upload_log.status = 'failed'
            upload_log.error = str(e)
            db.commit()
        
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
