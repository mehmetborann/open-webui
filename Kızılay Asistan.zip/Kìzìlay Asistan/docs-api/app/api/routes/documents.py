from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
import uuid
import logging
from app.core.database import get_db
from app.models.database import UploadLog
from app.schemas.upload import (
    UploadStatusResponse,
    UploadListResponse,
    UploadListItem,
    UploadResponse,
    RetryUploadRequest
)
from app.services.minio import MinIOService
from app.services.docling import DoclingService
from app.services.vector import VectorService

logger = logging.getLogger(__name__)

# Initialize services
minio_service = MinIOService()
docling_service = DoclingService()
vector_service = VectorService()

router = APIRouter(prefix="/uploads", tags=["documents"])


@router.get("/{upload_id}", response_model=UploadStatusResponse)
async def get_upload_status(upload_id: str, db: Session = Depends(get_db)):
    """Get upload status by ID"""
    from fastapi import HTTPException
    
    try:
        upload_uuid = uuid.UUID(upload_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid upload_id format")
    
    upload = db.query(UploadLog).filter(UploadLog.upload_id == upload_uuid).first()
    
    if not upload:
        raise HTTPException(status_code=404, detail="Upload not found")
    
    return UploadStatusResponse(
        upload_id=str(upload.upload_id),
        filename=upload.filename,
        status=upload.status,
        username=upload.username,
        tenant=upload.tenant,
        size=upload.size,
        mime=upload.mime,
        error=upload.error,
        created_at=upload.created_at,
        updated_at=upload.updated_at
    )


@router.get("", response_model=UploadListResponse)
async def list_uploads(
    skip: int = 0,
    limit: int = 10,
    status: Optional[str] = None,
    tenant: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """List uploads with optional filters"""
    query = db.query(UploadLog)
    
    if status:
        query = query.filter(UploadLog.status == status)
    
    if tenant:
        query = query.filter(UploadLog.tenant == tenant)
    
    query = query.order_by(UploadLog.created_at.desc())
    
    total = query.count()
    uploads = query.offset(skip).limit(limit).all()
    
    items = [
        UploadListItem(
            upload_id=str(upload.upload_id),
            filename=upload.filename,
            status=upload.status,
            username=upload.username,
            tenant=upload.tenant,
            created_at=upload.created_at
        )
        for upload in uploads
    ]
    
    return UploadListResponse(
        total=total,
        skip=skip,
        limit=limit,
        items=items
    )


@router.post("/retry", response_model=UploadResponse)
async def retry_upload(request: RetryUploadRequest, db: Session = Depends(get_db)):
    """
    Retry failed upload processing
    
    Downloads file from MinIO and reprocesses it:
    1. Get file from MinIO
    2. Convert with Docling
    3. Store in vector database
    """
    try:
        upload_uuid = uuid.UUID(request.upload_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid upload_id format")
    
    # Get upload record
    upload = db.query(UploadLog).filter(UploadLog.upload_id == upload_uuid).first()
    
    if not upload:
        raise HTTPException(status_code=404, detail="Upload not found")
    
    # Check if file exists in MinIO
    if not upload.object_key:
        raise HTTPException(status_code=400, detail="No file stored in MinIO")
    
    try:
        # Update status to processing
        upload.status = 'processing'
        upload.error = None
        db.commit()
        logger.info(f"Retrying upload {request.upload_id}, status updated to processing")
        
        # Download file from MinIO
        file_content = minio_service.get_file(upload.object_key)
        
        if not file_content:
            upload.status = 'failed'
            upload.error = 'Failed to download file from MinIO'
            db.commit()
            raise HTTPException(status_code=500, detail="Failed to download file from storage")
        
        logger.info(f"File downloaded from MinIO: {upload.object_key}")
        
        # Convert with Docling
        markdown_content = await docling_service.convert_to_markdown(
            file_content,
            upload.filename,
            upload.mime or 'application/octet-stream'
        )
        
        if not markdown_content:
            upload.status = 'failed'
            upload.error = 'Failed to convert document with Docling'
            db.commit()
            raise HTTPException(status_code=500, detail="Failed to convert document")
        
        logger.info(f"Document converted to markdown successfully")
        
        # Process and store in vector database
        metadata = {
            'filename': upload.filename,
            'mime_type': upload.mime,
            'username': upload.username,
            'tenant': upload.tenant,
            'upload_id': str(upload.upload_id)
        }
        
        vector_success = await vector_service.process_and_store_document(
            markdown_content,
            upload.upload_id,
            metadata
        )
        
        if not vector_success:
            upload.status = 'failed'
            upload.error = 'Failed to store in vector database'
            db.commit()
            raise HTTPException(status_code=500, detail="Failed to process document chunks")
        
        # Update status to completed
        upload.status = 'completed'
        db.commit()
        logger.info(f"Document reprocessing completed for upload_id: {request.upload_id}")
        
        return UploadResponse(
            message="Document reprocessed successfully",
            upload_id=str(upload.upload_id),
            status="completed",
            filename=upload.filename,
            hash=upload.hash,
            existing=True
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error reprocessing upload: {e}", exc_info=True)
        upload.status = 'failed'
        upload.error = str(e)
        db.commit()
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
