"""Core module - Configuration and Database"""
