import os
from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings - Values loaded from environment variables or .env file"""
    
    # Application
    APP_NAME: str
    APP_VERSION: str
    DEBUG: bool
    
    # Database (PostgreSQL)
    POSTGRES_USER: str
    POSTGRES_PASSWORD: str
    POSTGRES_HOST: str
    POSTGRES_PORT: int
    POSTGRES_DB: str
    
    @property
    def DATABASE_URL(self) -> str:
        """PostgreSQL connection string for vector store (LangChain PGVector format)"""
        return f"postgresql+psycopg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
    
    # MinIO
    MINIO_ENDPOINT: str
    MINIO_ACCESS_KEY: str
    MINIO_SECRET_KEY: str
    MINIO_BUCKET: str
    MINIO_SECURE: bool
    
    # Docling
    DOCLING_ENDPOINT: str
    
    # OpenAI (for embeddings)
    OPENAI_API_KEY: str
    OPENAI_EMBEDDING_MODEL: str
    
    # Vector Store
    VECTOR_COLLECTION_NAME: str
    
    # Application Settings
    UPLOAD_MAX_SIZE: int
    CHUNK_SIZE: int
    CHUNK_OVERLAP: int
    
    # CORS
    ALLOWED_ORIGINS: list
    
    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
