from sqlalchemy import Column, String, BigInteger, DateTime, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from datetime import datetime
import uuid
from app.core.database import Base


class UploadLog(Base):
    """Upload log model"""
    __tablename__ = "upload_logs"
    
    upload_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String(255), nullable=False)
    filename = Column(String(512), nullable=False)
    mime = Column(String(100))
    hash = Column(String(64), nullable=False, index=True)
    object_key = Column(String(1024))
    size = Column(BigInteger)
    tenant = Column(String(255), index=True)
    status = Column(String(50), default='pending', index=True)
    error = Column(Text)
    deleted_by = Column(String(255))
    deleted_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
