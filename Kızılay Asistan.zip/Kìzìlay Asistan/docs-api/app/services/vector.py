from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_postgres import PGVector
from langchain_core.documents import Document
from typing import List, Optional
import uuid
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)


class VectorService:
    """Vector service for document chunking and embedding with LangChain PGVector"""
    
    def __init__(self):
        self.embeddings = OpenAIEmbeddings(
            api_key=settings.OPENAI_API_KEY,
            model=settings.OPENAI_EMBEDDING_MODEL
        )
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.CHUNK_SIZE,
            chunk_overlap=settings.CHUNK_OVERLAP,
            length_function=len,
        )
        self.vectorstore = None
        self._initialize_vectorstore()
    
    def _initialize_vectorstore(self):
        """Initialize PGVector connection"""
        try:
            self.vectorstore = PGVector(
                embeddings=self.embeddings,
                collection_name=settings.VECTOR_COLLECTION_NAME,
                connection=settings.DATABASE_URL,
                use_jsonb=True,
            )
            logger.info(f"✓ PGVector initialized with collection: {settings.VECTOR_COLLECTION_NAME}")
        except Exception as e:
            logger.error(f"Failed to initialize PGVector: {e}")
            raise
    
    def split_text(self, text: str) -> List[str]:
        """Split text into chunks"""
        return self.text_splitter.split_text(text)
    
    async def process_and_store_document(
        self,
        markdown_content: str,
        upload_id: uuid.UUID,
        metadata: Optional[dict] = None
    ) -> bool:
        """
        Split markdown content into chunks and store in vector database using LangChain
        
        Args:
            markdown_content: The markdown text to process
            upload_id: UUID of the upload log
            metadata: Additional metadata to store with chunks
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if not self.vectorstore:
                logger.error("Vector store not initialized")
                return False
            
            # Prepare metadata
            base_metadata = metadata or {}
            base_metadata['upload_id'] = str(upload_id)
            
            # Create LangChain documents
            documents = []
            chunks = self.split_text(markdown_content)
            logger.info(f"Split document into {len(chunks)} chunks")
            
            if not chunks:
                logger.warning("No chunks created from document")
                return False
            
            for idx, chunk in enumerate(chunks):
                doc = Document(
                    page_content=chunk,
                    metadata={
                        **base_metadata,
                        'chunk_index': idx,
                        'total_chunks': len(chunks)
                    }
                )
                documents.append(doc)
            
            # Store in PGVector (batch operation)
            ids = self.vectorstore.add_documents(documents)
            logger.info(f"✓ Successfully stored {len(ids)} chunks for upload_id {upload_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error processing document: {e}", exc_info=True)
            return False
    
    def search_similar(
        self,
        query: str,
        k: int = 5,
        filter_metadata: Optional[dict] = None
    ) -> List[dict]:
        """
        Search for similar chunks using LangChain PGVector
        
        Args:
            query: Search query
            k: Number of results to return
            filter_metadata: Optional metadata filter
            
        Returns:
            List of similar chunks with metadata
        """
        try:
            if not self.vectorstore:
                logger.error("Vector store not initialized")
                return []
            
            # Perform similarity search
            if filter_metadata:
                results = self.vectorstore.similarity_search(
                    query, 
                    k=k,
                    filter=filter_metadata
                )
            else:
                results = self.vectorstore.similarity_search(query, k=k)
            
            # Format results
            formatted_results = []
            for doc in results:
                formatted_results.append({
                    'content': doc.page_content,
                    'metadata': doc.metadata
                })
            
            return formatted_results
            
        except Exception as e:
            logger.error(f"Error searching similar chunks: {e}", exc_info=True)
            return []

