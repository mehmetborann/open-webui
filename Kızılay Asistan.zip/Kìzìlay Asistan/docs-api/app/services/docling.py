import httpx
from typing import Optional
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)


class DoclingService:
    """Docling service for document conversion"""
    
    def __init__(self):
        self.endpoint = settings.DOCLING_ENDPOINT
    
    async def convert_to_markdown(
        self,
        file_data: bytes,
        filename: str,
        content_type: str
    ) -> Optional[str]:
        """
        Send file to Docling endpoint and get markdown output
        
        Args:
            file_data: File content as bytes
            filename: Original filename
            content_type: MIME type of the file
            
        Returns:
            Markdown content or None if failed
        """
        try:
            async with httpx.AsyncClient(timeout=300.0) as client:
                files = {
                    'file': (filename, file_data, content_type)
                }
                
                # Add any additional parameters here as needed
                # Example: data = {'param1': 'value1', 'param2': 'value2'}
                
                response = await client.post(
                    f"{self.endpoint}/convert",
                    files=files,
                    # data=data  # Uncomment and modify if Docling requires additional parameters
                )
                
                if response.status_code == 200:
                    result = response.json()
                    # Adjust based on actual Docling response structure
                    # This assumes Docling returns {'markdown': '...'}
                    markdown_content = result.get('markdown') or result.get('content') or response.text
                    logger.info(f"Successfully converted {filename} to markdown")
                    return markdown_content
                else:
                    logger.error(f"Docling conversion failed: {response.status_code} - {response.text}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error calling Docling endpoint: {e}")
            return None
