import hashlib
import io
from typing import Optional
from minio import Minio
from minio.error import S3Error
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)


class MinIOService:
    """MinIO service for object storage"""
    
    def __init__(self):
        self.client = Minio(
            settings.MINIO_ENDPOINT,
            access_key=settings.MINIO_ACCESS_KEY,
            secret_key=settings.MINIO_SECRET_KEY,
            secure=settings.MINIO_SECURE
        )
        self._ensure_bucket_exists()
    
    def _ensure_bucket_exists(self):
        """Create bucket if it doesn't exist"""
        try:
            if not self.client.bucket_exists(settings.MINIO_BUCKET):
                self.client.make_bucket(settings.MINIO_BUCKET)
                logger.info(f"Bucket '{settings.MINIO_BUCKET}' created")
        except S3Error as e:
            logger.error(f"Error checking/creating bucket: {e}")
            raise
    
    def upload_file(self, file_data: bytes, object_key: str, content_type: str) -> bool:
        """Upload file to MinIO"""
        try:
            file_stream = io.BytesIO(file_data)
            self.client.put_object(
                settings.MINIO_BUCKET,
                object_key,
                file_stream,
                length=len(file_data),
                content_type=content_type
            )
            logger.info(f"File uploaded successfully: {object_key}")
            return True
        except S3Error as e:
            logger.error(f"Error uploading file to MinIO: {e}")
            return False
    
    def get_file(self, object_key: str) -> Optional[bytes]:
        """Download file from MinIO"""
        try:
            response = self.client.get_object(settings.MINIO_BUCKET, object_key)
            data = response.read()
            response.close()
            response.release_conn()
            return data
        except S3Error as e:
            logger.error(f"Error downloading file from MinIO: {e}")
            return None
    
    def delete_file(self, object_key: str) -> bool:
        """Delete file from MinIO"""
        try:
            self.client.remove_object(settings.MINIO_BUCKET, object_key)
            logger.info(f"File deleted successfully: {object_key}")
            return True
        except S3Error as e:
            logger.error(f"Error deleting file from MinIO: {e}")
            return False


def calculate_file_hash(file_data: bytes) -> str:
    """Calculate SHA256 hash of file"""
    return hashlib.sha256(file_data).hexdigest()
