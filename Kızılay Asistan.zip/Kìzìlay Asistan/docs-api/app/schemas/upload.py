from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
import uuid


class UploadResponse(BaseModel):
    """Upload response schema"""
    message: str
    upload_id: str
    status: str
    filename: str
    hash: str
    existing: bool


class UploadStatusResponse(BaseModel):
    """Upload status response schema"""
    upload_id: str
    filename: str
    status: str
    username: str
    tenant: Optional[str] = None
    size: Optional[int] = None
    mime: Optional[str] = None
    error: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class UploadListItem(BaseModel):
    """Upload list item schema"""
    upload_id: str
    filename: str
    status: str
    username: str
    tenant: Optional[str] = None
    created_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class UploadListResponse(BaseModel):
    """Upload list response schema"""
    total: int
    skip: int
    limit: int
    items: list[UploadListItem]


class HealthResponse(BaseModel):
    """Health check response schema"""
    status: str
    timestamp: str


class ErrorResponse(BaseModel):
    """Error response schema"""
    detail: str


class RetryUploadRequest(BaseModel):
    """Retry upload request schema"""
    upload_id: str
