"""Pydantic schemas for request/response"""
