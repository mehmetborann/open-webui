#!/bin/bash
# Complete PostgreSQL Database Initialization
# This script creates all databases, tables, and schemas for Kızılay Asistan

set -e

echo "🚀 Starting database initialization..."

# ==========================================
# STEP 1: Create Databases
# ==========================================
echo "📦 Creating databases..."

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "postgres" <<-EOSQL
    -- Create main application database
    CREATE DATABASE kizilay_asistan;
    
    -- Create OpenWebUI database
    CREATE DATABASE openwebui;
    
    -- Grant privileges
    GRANT ALL PRIVILEGES ON DATABASE kizilay_asistan TO $POSTGRES_USER;
    GRANT ALL PRIVILEGES ON DATABASE openwebui TO $POSTGRES_USER;
EOSQL

echo "✅ Database 'kizilay_asistan' created"
echo "✅ Database 'openwebui' created"
echo "✅ Privileges granted to user '$POSTGRES_USER'"

# ==========================================
# STEP 2: Create Schema in kizilay_asistan
# ==========================================
echo "📊 Creating tables in 'kizilay_asistan'..."

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "kizilay_asistan" <<-EOSQL

    -- ==========================================
    -- Chat History Tables (AI Agent)
    -- ==========================================
    
    -- Chat sessions table
    CREATE TABLE IF NOT EXISTS chat_sessions (
        conversation_id VARCHAR(255) PRIMARY KEY,
        username VARCHAR(255),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        metadata JSONB DEFAULT '{}'::jsonb
    );

    -- Chat messages table
    CREATE TABLE IF NOT EXISTS chat_messages (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        conversation_id VARCHAR(255) NOT NULL REFERENCES chat_sessions(conversation_id) ON DELETE CASCADE,
        message_type VARCHAR(50) NOT NULL,
        content TEXT NOT NULL,
        metadata JSONB DEFAULT '{}'::jsonb,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT valid_message_type CHECK (message_type IN ('human', 'ai', 'system', 'tool'))
    );

    -- Chat indexes
    CREATE INDEX IF NOT EXISTS idx_chat_sessions_username ON chat_sessions(username);
    CREATE INDEX IF NOT EXISTS idx_chat_sessions_created_at ON chat_sessions(created_at);
    CREATE INDEX IF NOT EXISTS idx_chat_messages_conversation_id ON chat_messages(conversation_id);
    CREATE INDEX IF NOT EXISTS idx_chat_messages_created_at ON chat_messages(created_at);

    -- ==========================================
    -- Document Management Tables (Docs API)
    -- ==========================================
    
    -- Enable pgvector extension for embeddings
    CREATE EXTENSION IF NOT EXISTS vector;

    -- Upload logs table
    CREATE TABLE IF NOT EXISTS upload_logs (
        upload_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        username VARCHAR(255) NOT NULL,
        filename VARCHAR(512) NOT NULL,
        mime VARCHAR(100),
        hash VARCHAR(64) NOT NULL,
        object_key VARCHAR(1024),
        size BIGINT,
        tenant VARCHAR(255),
        status VARCHAR(50) DEFAULT 'pending',
        error TEXT,
        deleted_by VARCHAR(255),
        deleted_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Upload logs indexes
    CREATE INDEX IF NOT EXISTS idx_upload_logs_hash ON upload_logs(hash);
    CREATE INDEX IF NOT EXISTS idx_upload_logs_status ON upload_logs(status);
    CREATE INDEX IF NOT EXISTS idx_upload_logs_tenant ON upload_logs(tenant);

EOSQL

echo "✅ Chat tables created (chat_sessions, chat_messages)"
echo "✅ Document tables created (upload_logs)"
echo "✅ PGVector extension enabled"
echo "✅ All indexes and triggers created"

# ==========================================
# Completion
# ==========================================
echo "🎉 Database initialization completed successfully!"
echo ""
echo "📋 Summary:"
echo "   • Databases: kizilay_asistan, openwebui"
echo "   • Tables: chat_sessions, chat_messages, upload_logs"
echo "   • Extensions: vector (pgvector)"
echo "   • Indexes: 7 indexes created"
