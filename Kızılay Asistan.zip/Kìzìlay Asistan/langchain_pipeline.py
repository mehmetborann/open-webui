"""
title: LangChain AI Agent Pipeline
author: Mehmet Boran
version: 1.0.0
license: MIT
description: A pipeline for connecting Open WebUI to LangChain AI Agent with full streaming support
features:
  - Real-time token-level streaming responses
  - Full conversation history support
  - Bearer token authentication
  - Status indicators
  - Tool call visibility
"""

import time
import aiohttp
import logging
import json
from typing import Optional, Callable, Awaitable, Any, Dict, List
from pydantic import BaseModel, Field

log = logging.getLogger(__name__)


class Pipe:
    class Valves(BaseModel):
        LANGCHAIN_API_URL: str = Field(
            default="http://ai-agent:8080/api/chat",
            description="LangChain API endpoint URL",
        )
        LANGCHAIN_BEARER_TOKEN: str = Field(
            default="langchain-secure-api-key-2025",
            description="Bearer token for API authentication",
        )
        EMIT_INTERVAL: float = Field(
            default=1.0, description="Interval in seconds between status emissions"
        )
        ENABLE_STATUS_INDICATOR: bool = Field(
            default=True, description="Enable or disable status indicator emissions"
        )
        SHOW_TOOL_CALLS: bool = Field(
            default=True, description="Show tool calls in the response"
        )

    def __init__(self):
        self.name = "LangChain AI Agent"
        self.valves = self.Valves()
        self.last_emit_time = 0

    async def emit_status(
        self,
        event_emitter: Optional[Callable[[dict], Awaitable[None]]],
        level: str,
        message: str,
        done: bool = False,
    ) -> None:
        """Emit status updates to Open WebUI"""
        if not event_emitter or not self.valves.ENABLE_STATUS_INDICATOR:
            return

        current_time = time.time()
        if current_time - self.last_emit_time >= self.valves.EMIT_INTERVAL or done:
            await event_emitter(
                {
                    "type": "status",
                    "data": {
                        "status": "complete" if done else "in_progress",
                        "level": level,
                        "description": message,
                        "done": done,
                    },
                }
            )
            self.last_emit_time = current_time

    def extract_chat_id(self, event_emitter: Optional[Callable]) -> Optional[str]:
        """Extract chat_id from event emitter closure"""
        if (
            not event_emitter
            or not hasattr(event_emitter, "__closure__")
            or not event_emitter.__closure__
        ):
            return None

        for cell in event_emitter.__closure__:
            if hasattr(cell, "cell_contents") and isinstance(cell.cell_contents, dict):
                request_info = cell.cell_contents
                return request_info.get("chat_id")
        return None

    def build_payload(
        self,
        messages: List[dict],
        user: Optional[dict],
        chat_id: Optional[str],
    ) -> dict:
        """Build the payload for LangChain API request"""
        if not messages:
            return {}

        # Extract the current user's message
        user_message = messages[-1].get("content", "")

        # Use chat_id as conversation_id, fallback to "default"
        conversation_id = chat_id or "default"

        # Extract username from user object
        username = None
        if user:
            username = user.get("id") or user.get("email") or user.get("name")

        payload = {
            "message": user_message,
            "conversation_id": conversation_id,
            "username": username or "anonymous",
            "stream": True,
        }

        return payload

    async def pipe(
        self,
        body: dict,
        __user__: Optional[dict] = None,
        __event_emitter__: Optional[Callable[[dict], Awaitable[None]]] = None,
        __event_call__: Optional[Callable[[dict], Awaitable[dict]]] = None,
    ) -> str:
        """Main pipeline function"""

        messages = body.get("messages", [])
        if not messages:
            error_msg = "İstek gövdesinde mesaj bulunamadı"
            log.warning(error_msg)
            await self.emit_status(__event_emitter__, "error", error_msg, True)
            return error_msg

        langchain_response = ""
        tool_calls_info = []

        try:
            # Extract chat_id from event emitter
            chat_id = self.extract_chat_id(__event_emitter__)

            # Build request payload
            payload = self.build_payload(messages, __user__, chat_id)

            headers = {
                "Authorization": f"Bearer {self.valves.LANGCHAIN_BEARER_TOKEN}",
                "Content-Type": "application/json",
            }

            log.info(
                f"Sending request to LangChain API: {self.valves.LANGCHAIN_API_URL}"
            )
            await self.emit_status(__event_emitter__, "info", "Düşünüyor...")

            async with aiohttp.ClientSession(
                trust_env=True,
                timeout=aiohttp.ClientTimeout(total=None),
            ) as session:
                async with session.post(
                    self.valves.LANGCHAIN_API_URL, json=payload, headers=headers
                ) as response:

                    if response.status != 200:
                        error_text = await response.text()
                        raise Exception(
                            f"LangChain API HTTP {response.status} hatası: {error_text}"
                        )

                    # Check if it's streaming response
                    content_type = response.headers.get("Content-Type", "").lower()
                    is_streaming = "event-stream" in content_type

                    if is_streaming:
                        # --- STREAMING MODE ---
                        log.info("Processing streaming response from LangChain API")

                        async for line in response.content:
                            if not line:
                                continue

                            decoded_line = line.decode("utf-8").strip()

                            # Skip empty lines
                            if not decoded_line:
                                continue

                            # Handle SSE format: "data: {...}"
                            if decoded_line.startswith("data: "):
                                data_str = decoded_line[6:]  # Remove "data: " prefix

                                # Check for end of stream
                                if data_str.strip() == "[DONE]":
                                    log.info("Streaming completed")
                                    break

                                try:
                                    chunk = json.loads(data_str)

                                    if isinstance(chunk, dict):
                                        # Skip chunks with only metadata fields (title, tags, etc.)
                                        # But keep chunks that have actual content
                                        if not any(
                                            key in chunk
                                            for key in [
                                                "type",
                                                "content",
                                                "text",
                                                "message",
                                                "output",
                                            ]
                                        ):
                                            # This chunk only has metadata, skip it
                                            log.debug(
                                                f"Skipping metadata-only chunk: {list(chunk.keys())}"
                                            )
                                            continue

                                    # Handle token chunks
                                    if chunk.get("type") == "token":
                                        content = chunk.get("content", "")
                                        if content:
                                            langchain_response += content

                                            # Emit delta to Open WebUI for real-time display
                                            if __event_emitter__:
                                                await __event_emitter__(
                                                    {
                                                        "type": "message",
                                                        "data": {"content": content},
                                                    }
                                                )

                                    # Handle tool call information
                                    elif chunk.get("type") == "tool_call":
                                        tool_name = chunk.get("tool_name", "bilinmeyen")
                                        tool_calls_info.append(tool_name)
                                        await self.emit_status(
                                            __event_emitter__,
                                            "info",
                                            f"🔧 Araç kullanılıyor: {tool_name}",
                                        )

                                    # Handle error chunks
                                    elif chunk.get("type") == "error":
                                        error_msg = chunk.get(
                                            "error", "Bilinmeyen hata"
                                        )
                                        log.error(f"Stream error: {error_msg}")
                                        await self.emit_status(
                                            __event_emitter__,
                                            "error",
                                            f"Hata: {error_msg}",
                                        )

                                except json.JSONDecodeError as e:
                                    log.warning(
                                        f"Failed to parse JSON chunk: {data_str[:100]}"
                                    )
                                    continue

                        # Add tool calls summary if enabled
                        if self.valves.SHOW_TOOL_CALLS and tool_calls_info:
                            tools_used = ", ".join(set(tool_calls_info))
                            tool_summary = (
                                f"\n\n---\n*Kullanılan araçlar: {tools_used}*"
                            )
                            langchain_response += tool_summary

                    else:
                        # --- NON-STREAMING MODE (fallback) ---
                        log.info("Processing non-streaming response from LangChain API")

                        try:
                            response_data = await response.json()
                            langchain_response = response_data.get("response", "")

                            # Check for tool calls in metadata
                            if (
                                self.valves.SHOW_TOOL_CALLS
                                and "tool_calls" in response_data
                            ):
                                tool_calls = response_data.get("tool_calls", [])
                                if tool_calls:
                                    tools_used = ", ".join(
                                        [
                                            tc.get("name", "bilinmeyen")
                                            for tc in tool_calls
                                        ]
                                    )
                                    langchain_response += (
                                        f"\n\n---\n*Kullanılan araçlar: {tools_used}*"
                                    )

                        except json.JSONDecodeError:
                            raw_text = await response.text()
                            langchain_response = raw_text

            await self.emit_status(__event_emitter__, "info", "Tamamlandı", done=True)

        except Exception as e:
            error_msg = f"Hata: {str(e)}"
            log.exception(error_msg)
            await self.emit_status(__event_emitter__, "error", error_msg, True)
            return error_msg

        return langchain_response
